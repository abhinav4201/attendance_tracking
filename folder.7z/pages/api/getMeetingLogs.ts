import { NextApiRequest, NextApiResponse } from "next";
import db from "../../lib/db";

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  // Fetch logs from database
  const logs = db
    .prepare(`SELECT * FROM meeting_logs ORDER BY joined_at DESC`)
    .all();

  res.status(200).json({ logs });
}
