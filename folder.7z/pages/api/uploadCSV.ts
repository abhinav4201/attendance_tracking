import fs from "fs";
import path from "path";
import sqlite3 from "sqlite3";
import { open } from "sqlite";
import formidable from "formidable";
import { NextApiRequest, NextApiResponse } from "next";
import { parse } from "csv-parse";

export const config = {
  api: {
    bodyParser: false, // Required for file uploads
  },
};

// Open SQLite DB Connection
const openDB = async () => {
  return open({
    filename: "./database.sqlite",
    driver: sqlite3.Database,
  });
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method Not Allowed" });
  }

  const form = new formidable.IncomingForm({
    multiples: false, // Allows single file upload
    keepExtensions: true, // Keeps original file extension
    uploadDir: path.join(process.cwd(), "public"), // Define the upload path correctly
  });


  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ message: "File upload failed" });

    const file = files.file?.[0]; // Get uploaded file
    if (!file) return res.status(400).json({ message: "No file uploaded" });

    const filePath = path.join(process.cwd(), "public", "student_data.csv");
    fs.renameSync(file.filepath, filePath);

    const studentData: any[] = [];
    const parser = fs.createReadStream(filePath).pipe(parse({ columns: true }));

    for await (const record of parser) {
      studentData.push({
        roll_number: record["Roll Number"],
        name: record["Name"],
        email: record["Email"],
        phone: record["Phone"],
      });
    }

    const db = await openDB();

    // Clear & Insert Data into SQLite
    await db.exec("DELETE FROM students");
    const stmt = await db.prepare(
      "INSERT INTO students (roll_number, name, email, phone) VALUES (?, ?, ?, ?)"
    );

    for (const student of studentData) {
      await stmt.run(
        student.roll_number,
        student.name,
        student.email,
        student.phone
      );
    }
    await stmt.finalize();

    return res
      .status(200)
      .json({ message: "✅ Student Data Updated Successfully!" });
  });
}
