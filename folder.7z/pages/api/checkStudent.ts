import { NextApiRequest, NextApiResponse } from "next";
import db from "../../lib/db";

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  const { name, email, rollNumber, phone } = req.body;

  // Query database for student
  const student = db
    .prepare(
      `SELECT * FROM students 
       WHERE roll_number = ? OR email = ? OR phone = ?`
    )
    .get(rollNumber, email, phone);

  if (student) {
    // Log meeting access
    db.prepare(
      `INSERT INTO meeting_logs (name, roll_number, email, phone, meeting_link) 
       VALUES (?, ?, ?, ?, ?)`
    ).run(
      student.name,
      student.roll_number,
      student.email,
      student.phone,
      student.meeting_link
    );

    return res.status(200).json({
      success: true,
      meetingLink: student.meeting_link,
    });
  } else {
    return res.status(404).json({
      success: false,
      message: "Student not found. Please check the details and try again.",
    });
  }
}
