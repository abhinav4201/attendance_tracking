import { useState, useEffect } from "react";

type LogEntry = {
  id: number;
  name: string;
  roll_number: string;
  email: string;
  phone: string;
  meeting: string; // Meeting name (optional)
  meeting_link: string; // Meeting URL
  joined_at: string;
};

export default function AdminPage() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<LogEntry[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>("");

  useEffect(() => {
    fetch("/api/getMeetingLogs")
      .then((res) => res.json())
      .then((data) => {
        setLogs(data.logs);
        setFilteredLogs(data.logs);
      });
  }, []);

  // Convert to Indian Standard Time (IST)
  const formatIST = (dateString: string) => {
    const utcDate = new Date(dateString);
    return utcDate.toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
  };

  // Extract Meeting ID from Link (e.g., "https://meet.google.com/uim-hiah-scb" → "uim-hiah-scb")
  const extractMeetingID = (link: string) => {
    if (!link) return "Unknown";
    const parts = link.split("/");
    return parts[parts.length - 1]; // Get the last segment (meeting ID)
  };

  // Handle Date Filter
  const handleDateFilter = (e: React.ChangeEvent<HTMLInputElement>) => {
    const date = e.target.value;
    setSelectedDate(date);

    if (!date) {
      setFilteredLogs(logs);
      return;
    }

    const filtered = logs.filter((log) => log.joined_at.startsWith(date));
    setFilteredLogs(filtered);
  };

  // Get Meeting-wise Student Count
  const meetingCounts = filteredLogs.reduce((acc, log) => {
    const meetingID = extractMeetingID(log.meeting_link);
    acc[meetingID] = (acc[meetingID] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Download CSV function
  const downloadCSV = () => {
    const csvRows = [
      ["Name", "Roll Number", "Email", "Phone", "Meeting ID", "Joined At"],
      ...filteredLogs.map((log) => [
        log.name,
        log.roll_number,
        log.email,
        log.phone,
        extractMeetingID(log.meeting_link),
        formatIST(log.joined_at),
      ]),
    ];

    const csvContent = csvRows.map((row) => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "meeting_logs.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className='container'>
      <h2>Meeting Logs</h2>

      {/* Date Filter */}
      <div className='filter-section'>
        <label>Filter by Date:</label>
        <input type='date' value={selectedDate} onChange={handleDateFilter} />
      </div>

      {/* Meeting-wise Count Display */}
      <div className='meeting-counts'>
        {Object.keys(meetingCounts).map((meetingID) => (
          <p key={meetingID}>
            <strong>{meetingID}:</strong> {meetingCounts[meetingID]} students
            joined
          </p>
        ))}
      </div>

      {/* Download CSV Button */}
      <button className='download-btn' onClick={downloadCSV}>
        Download CSV
      </button>

      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Roll Number</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Meeting Link</th>
            <th>Joined At</th>
          </tr>
        </thead>
        <tbody>
          {filteredLogs.map((log) => (
            <tr key={log.id}>
              <td>{log.name}</td>
              <td>{log.roll_number}</td>
              <td>{log.email}</td>
              <td>{log.phone}</td>
              <td>
                {log.meeting_link ? (
                  <a
                    href={log.meeting_link}
                    target='_blank'
                    rel='noopener noreferrer'
                  >
                    {extractMeetingID(log.meeting_link)} 🔗
                  </a>
                ) : (
                  "No Link"
                )}
              </td>
              <td>{formatIST(log.joined_at)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <style jsx>{`
        .container {
          padding: 20px;
        }
        .filter-section {
          margin-bottom: 10px;
        }
        .download-btn {
          margin-bottom: 10px;
          padding: 8px;
          background-color: #007bff;
          color: white;
          border: none;
          cursor: pointer;
        }
        table {
          width: 100%;
          border-collapse: collapse;
        }
        th,
        td {
          padding: 10px;
          border: 1px solid #ccc;
        }
        th {
          background-color: #f8f8f8;
        }
      `}</style>
    </div>
  );
}
