import { useState } from "react";

export default function Home() {
  const [formData, setFormData] = useState({
    name: "",
    rollNumber: "",
    phone: "",
    email: "",
  });

  const [meetingLink, setMeetingLink] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (name === "phone" && !/^\d*$/.test(value)) return;
    setFormData({ ...formData, [name]: value });
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setMeetingLink(null);

    const response = await fetch("/api/checkStudent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });

    const data = await response.json();
    setLoading(false);

    if (data.success) {
      setMeetingLink(data.meetingLink);
    } else {
      setError("Your data is not found. Please check your details.");
    }
  };

  return (
    <div className='container'>
      <div className='form-box'>
        <h2>Student Verification</h2>

        <form onSubmit={handleSubmit}>
          <div className='form-group'>
            <label>Name</label>
            <input
              type='text'
              name='name'
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className='form-group'>
            <label>Roll Number</label>
            <input
              type='text'
              name='rollNumber'
              value={formData.rollNumber}
              onChange={handleChange}
              required
            />
          </div>

          <div className='form-group'>
            <label>Phone Number</label>
            <input
              type='tel'
              name='phone'
              value={formData.phone}
              onChange={handleChange}
              maxLength={10}
              required
            />
          </div>

          <div className='form-group'>
            <label>Email</label>
            <input
              type='email'
              name='email'
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <button type='submit' className='submit-button' disabled={loading}>
            {loading ? "Checking..." : "Get Meeting Link"}
          </button>
        </form>

        {error && <div className='error-message'>{error}</div>}
        {meetingLink && (
          <div className='success-message'>
            ✅ Meeting Found:{" "}
            <a href={meetingLink} target='_blank' rel='noopener noreferrer'>
              Join Now
            </a>
          </div>
        )}
      </div>

      {/* NORMAL CSS */}
      <style jsx>{`
        .container {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
          background-color: #f4f4f4;
        }

        .form-box {
          width: 400px;
          background: white;
          padding: 25px; /* ✅ Keep padding uniform */
          padding-bottom: 35px; /* ✅ Extra padding at bottom */
          border-radius: 10px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
          text-align: center;
        }

        h2 {
          margin-bottom: 15px;
          font-size: 22px;
          font-weight: bold;
          color: #333;
        }

        .form-group {
          text-align: left;
          margin-bottom: 15px;
        }

        label {
          display: block;
          font-weight: 600;
          margin-bottom: 5px;
          color: #555;
        }

        input {
          width: 95%;
          padding: 10px;
          border: 2px solid #ddd;
          border-radius: 6px;
          font-size: 14px;
          outline: none;
          transition: border 0.3s;
        }

        input:focus {
          border-color: #007bff;
        }

        .submit-button {
          width: 100%;
          background-color: #007bff;
          color: white;
          padding: 10px;
          border: none;
          border-radius: 6px;
          font-size: 16px;
          font-weight: bold;
          cursor: pointer;
          transition: background 0.3s;
        }

        .submit-button:hover {
          background-color: #0056b3;
        }

        .error-message {
          background-color: #e74c3c;
          color: white;
          padding: 10px;
          border-radius: 6px;
          margin-top: 10px;
        }

        .success-message {
          background-color: #27ae60;
          color: white;
          padding: 10px;
          border-radius: 6px;
          margin-top: 10px;
        }
      `}</style>
    </div>
  );
}
