"use strict";(()=>{var e={};e.id=377,e.ids=[377],e.modules={1512:(e,t,n)=>{n.r(t),n.d(t,{config:()=>u,default:()=>l,routeModule:()=>d});var r={};n.r(r),n.d(r,{default:()=>T});var i=n(3480),E=n(8667),o=n(6435),a=n(2792);function T(e,t){if("GET"!==e.method)return t.status(405).json({error:"Method Not Allowed"});let n=a.A.prepare("SELECT * FROM meeting_logs ORDER BY joined_at DESC").all();t.status(200).json({logs:n})}let l=(0,o.M)(r,"default"),u=(0,o.M)(r,"config"),d=new i.PagesAPIRouteModule({definition:{kind:E.A.PAGES_API,page:"/api/getMeetingLogs",pathname:"/api/getMeetingLogs",bundlePath:"",filename:""},userland:r})},2792:(e,t,n)=>{n.d(t,{A:()=>T});let r=require("better-sqlite3");var i=n.n(r);let E=require("path");var o=n.n(E);let a=new(i())(o().join(process.cwd(),"database.sqlite"));a.exec(`
  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    roll_number TEXT UNIQUE,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    meeting_link TEXT
  );

  CREATE TABLE IF NOT EXISTS meeting_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    roll_number TEXT,
    email TEXT,
    phone TEXT,
    meeting_link TEXT,
    joined_at DATETIME DEFAULT (datetime('now', 'localtime'))
  );
`);let T=a},3480:(e,t,n)=>{e.exports=n(5600)},5600:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6435:(e,t)=>{Object.defineProperty(t,"M",{enumerable:!0,get:function(){return function e(t,n){return n in t?t[n]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,n)):"function"==typeof t&&"default"===n?t:void 0}}})},8667:(e,t)=>{Object.defineProperty(t,"A",{enumerable:!0,get:function(){return n}});var n=function(e){return e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE",e.IMAGE="IMAGE",e}({})}};var t=require("../../webpack-api-runtime.js");t.C(e);var n=t(t.s=1512);module.exports=n})();