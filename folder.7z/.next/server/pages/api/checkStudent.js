"use strict";(()=>{var e={};e.id=658,e.ids=[658],e.modules={2792:(e,t,n)=>{n.d(t,{A:()=>E});let r=require("better-sqlite3");var i=n.n(r);let a=require("path");var o=n.n(a);let u=new(i())(o().join(process.cwd(),"database.sqlite"));u.exec(`
  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    roll_number TEXT UNIQUE,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    meeting_link TEXT
  );

  CREATE TABLE IF NOT EXISTS meeting_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    roll_number TEXT,
    email TEXT,
    phone TEXT,
    meeting_link TEXT,
    joined_at DATETIME DEFAULT (datetime('now', 'localtime'))
  );
`);let E=u},3480:(e,t,n)=>{e.exports=n(5600)},5600:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6435:(e,t)=>{Object.defineProperty(t,"M",{enumerable:!0,get:function(){return function e(t,n){return n in t?t[n]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,n)):"function"==typeof t&&"default"===n?t:void 0}}})},7307:(e,t,n)=>{n.r(t),n.d(t,{config:()=>s,default:()=>l,routeModule:()=>T});var r={};n.r(r),n.d(r,{default:()=>E});var i=n(3480),a=n(8667),o=n(6435),u=n(2792);function E(e,t){if("POST"!==e.method)return t.status(405).json({error:"Method Not Allowed"});let{name:n,email:r,rollNumber:i,phone:a}=e.body,o=u.A.prepare(`SELECT * FROM students 
       WHERE roll_number = ? OR email = ? OR phone = ?`).get(i,r,a);return o?(u.A.prepare(`INSERT INTO meeting_logs (name, roll_number, email, phone, meeting_link) 
       VALUES (?, ?, ?, ?, ?)`).run(o.name,o.roll_number,o.email,o.phone,o.meeting_link),t.status(200).json({success:!0,meetingLink:o.meeting_link})):t.status(404).json({success:!1,message:"Student not found. Please check the details and try again."})}let l=(0,o.M)(r,"default"),s=(0,o.M)(r,"config"),T=new i.PagesAPIRouteModule({definition:{kind:a.A.PAGES_API,page:"/api/checkStudent",pathname:"/api/checkStudent",bundlePath:"",filename:""},userland:r})},8667:(e,t)=>{Object.defineProperty(t,"A",{enumerable:!0,get:function(){return n}});var n=function(e){return e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE",e.IMAGE="IMAGE",e}({})}};var t=require("../../webpack-api-runtime.js");t.C(e);var n=t(t.s=7307);module.exports=n})();