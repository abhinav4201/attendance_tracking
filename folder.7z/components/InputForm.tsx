"use client"; // Needed for Next.js App Router (if using Pages Router, remove this)

import { useState } from "react";
import { useRouter } from "next/navigation";

const InputForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    rollNumber: "",
  });

  const [error, setError] = useState("");
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const response = await fetch("/api/checkStudent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });

    const data = await response.json();

    if (data.success) {
      router.push(data.meetingLink);
    } else {
      setError("Student not found. Please check your details.");
    }
  };

  return (
    <div className='max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md'>
      <h2 className='text-xl font-bold mb-4'>Enter Your Details</h2>
      <form onSubmit={handleSubmit} className='space-y-4'>
        <input
          type='text'
          name='name'
          placeholder='Full Name'
          value={formData.name}
          onChange={handleChange}
          className='w-full p-2 border rounded'
          required
        />
        <input
          type='email'
          name='email'
          placeholder='Email'
          value={formData.email}
          onChange={handleChange}
          className='w-full p-2 border rounded'
          required
        />
        <input
          type='tel'
          name='phone'
          placeholder='Phone'
          value={formData.phone}
          onChange={handleChange}
          className='w-full p-2 border rounded'
          required
        />
        <input
          type='text'
          name='rollNumber'
          placeholder='Roll Number'
          value={formData.rollNumber}
          onChange={handleChange}
          className='w-full p-2 border rounded'
          required
        />
        {error && <p className='text-red-500'>{error}</p>}
        <button
          type='submit'
          className='w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600'
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default InputForm;
