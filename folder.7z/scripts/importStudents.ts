import fs from "fs";
import path from "path";
import Papa from "papaparse";
import db from "../lib/db";

// Read CSV file
const csvPath = path.join(process.cwd(), "public", "student_data.csv");
const csvFile = fs.readFileSync(csvPath, "utf8");

// Parse CSV
const { data } = Papa.parse(csvFile, {
  header: true,
  skipEmptyLines: true,
}) as { data: any[] };

// Insert students into database
const insert = db.prepare(`
  INSERT INTO students (name, roll_number, email, phone, meeting_link) 
  VALUES (?, ?, ?, ?, ?)
`);

db.transaction(() => {
  data.forEach((student) => {
    const existing = db
      .prepare(`SELECT 1 FROM students WHERE email = ?`)
      .get(student["Student Email"]);

    if (!existing) {
      insert.run(
        student["Student Name"],
        student["Class Roll"],
        student["Student Email"],
        student["Student WhatsApp"],
        student["Meeting Link"]
      );
    } else {
      console.log(`❌ Skipping duplicate email: ${student["Student Email"]}`);
    }
  });

})();

console.log("✅ Students imported successfully!");
